package com.cometproject.process.processes;

public enum ProcessStatus {
    UP,
    DOWN,
    WARNING,
    RESTARTING,
    STOPPING,
    STARTING
}
