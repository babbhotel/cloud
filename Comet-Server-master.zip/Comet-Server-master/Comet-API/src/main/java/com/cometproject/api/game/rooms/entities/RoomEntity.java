package com.cometproject.api.game.rooms.entities;

public interface RoomEntity {
    int getId();


}
