package com.cometproject.api.messaging.console;

import io.coerce.services.messaging.client.messages.response.MessageResponse;

public class ConsoleCommandResponse implements MessageResponse {
}
