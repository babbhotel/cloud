package com.cometproject.api.messaging.performance;

import io.coerce.services.messaging.client.messages.response.MessageResponse;

public class QueryResponse implements MessageResponse {
}
