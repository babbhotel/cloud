package com.cometproject.api.networking.messages;

public class IMessageEvent {
}
