package com.cometproject.api.game.rooms.settings;

public enum RoomAccessType {
    OPEN,
    DOORBELL,
    PASSWORD,
    INVISIBLE
}
