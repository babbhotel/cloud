package com.cometproject.api.game.players.data.types;

public interface IVolumeData {
    int getSystemVolume();

    void setSystemVolume(int systemVolume);

    int getFurniVolume();

    void setFurniVolume(int furniVolume);

    int getTraxVolume();

    void setTraxVolume(int traxVolume);
}
