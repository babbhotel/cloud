package com.cometproject.api.events;

public interface EventListenerContainer {
}
