package com.cometproject.api.game.rooms;

public interface IRoom {
    IRoomData getData();
}
