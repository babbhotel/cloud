package com.cometproject.server.game.commands.staff.muting;

import com.cometproject.server.boot.Comet;
import com.cometproject.server.config.Locale;
import com.cometproject.server.game.commands.ChatCommand;
import com.cometproject.server.game.players.PlayerManager;
import com.cometproject.server.game.rooms.objects.entities.types.PlayerEntity;
import com.cometproject.server.logging.LogEntryType;
import com.cometproject.server.logging.LogManager;
import com.cometproject.server.logging.entries.StaffLogEntry;
import com.cometproject.server.network.NetworkManager;
import com.cometproject.server.network.messages.outgoing.notification.AdvancedAlertMessageComposer;
import com.cometproject.server.network.sessions.Session;
import com.cometproject.server.storage.queries.player.PlayerDao;


public class UnmuteCommand extends ChatCommand {
    @Override
    public void execute(Session client, String[] params) {
        if (params.length != 1) {
            sendNotif(Locale.getOrDefault("command.unmute.none", "Who do you want to unmute?"), client);
            return;
        }

        int playerId = PlayerManager.getInstance().getPlayerIdByUsername(params[0]);
        Session session = NetworkManager.getInstance().getSessions().getByPlayerId(playerId);

        if (session == null) {
            sendNotif(Locale.getOrDefault("command.user.offline", "This user is offline!"), client);
            return;
        }

        if (playerId != -1) {
            final int timeMuted = 0;

            try {
                if (LogManager.ENABLED)
                    LogManager.getInstance().getStore().getLogEntryContainer().putStaff(new StaffLogEntry(client.getPlayer().getId(), playerId, Locale.get("command.unmute.name"), LogEntryType.ALERT));
            } catch (Exception ignored) {

            }

            session.send(new AdvancedAlertMessageComposer(Locale.get("command.unmute.unmuted")));

            if (session.getPlayer().getData().getTimeMuted() > (int) Comet.getTime()) {
                PlayerDao.addTimeMute(playerId, timeMuted);
                session.getPlayer().getData().setTimeMuted(timeMuted);
                isExecuted(client);
            } else {
                PlayerEntity entity = session.getPlayer().getEntity();

                if (entity != null && entity.isRoomMuted()) {
                    entity.setRoomMuted(false);
                }
                isExecuted(client);
            }
        }
    }

    @Override
    public String getPermission() {
        return "unmute_command";
    }
    
    @Override
    public String getParameter() {
        return Locale.getOrDefault("command.parameter.username", "%username%");
    }

    @Override
    public String getDescription() {
        return Locale.get("command.unmute.description");
    }

    @Override
    public boolean bypassFilter() {
        return true;
    }
}