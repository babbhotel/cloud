package com.cometproject.server.game.bots;

public abstract class PetData implements BotInformation {
    // Now we can add pet specific things here like leveling up, interactions and all that cool pet stuff!
}