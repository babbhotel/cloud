package com.cometproject.server.game.rooms.objects.entities.types.data;

public interface BotDataObject {

}
