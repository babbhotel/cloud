package com.cometproject.server.game.rooms.objects.entities.pathfinding;

public class Square {
    public int x;
    public int y;

    public Square(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
