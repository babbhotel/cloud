package com.cometproject.server.game.commands.staff;

import com.cometproject.server.config.Locale;
import com.cometproject.server.game.commands.ChatCommand;
import com.cometproject.server.logging.LogEntryType;
import com.cometproject.server.logging.LogManager;
import com.cometproject.server.logging.entries.StaffLogEntry;
import com.cometproject.server.network.NetworkManager;
import com.cometproject.server.network.sessions.Session;


public class RemoveBadgeCommand extends ChatCommand {
    @Override
    public void execute(Session client, String[] params) {
        if (params.length < 2)
            return;

        Session session = NetworkManager.getInstance().getSessions().getByPlayerUsername(params[0]);

        if (session != null) {
            try {
                if (LogManager.ENABLED)
                    LogManager.getInstance().getStore().getLogEntryContainer().putStaff(new StaffLogEntry(client.getPlayer().getId(), session.getPlayer().getId(), "Command: " + Locale.get("command.removebadge.name") + " " + session.getPlayer().getData().getUsername(), LogEntryType.NONE));
            } catch (Exception ignored) {

            }

            session.getPlayer().getInventory().removeBadge(params[1], true);
        }
    }

    @Override
    public String getPermission() {
        return "removebadge_command";
    }

    @Override
    public String getParameter() {
        return Locale.getOrDefault("command.parameter.username" + " " + "command.parameter.badge", "%username% %badge%");
    }

    @Override
    public String getDescription() {
        return Locale.get("command.removebadge.description");
    }
}