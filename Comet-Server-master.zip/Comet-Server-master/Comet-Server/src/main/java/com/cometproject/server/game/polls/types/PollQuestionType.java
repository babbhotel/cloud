package com.cometproject.server.game.polls.types;

public enum PollQuestionType {
    WORDED,
    MULTIPLE_CHOICE,
    SINGLE_CHOICE
}
