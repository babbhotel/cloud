package com.cometproject.server.game.rooms.objects.entities;

public enum RoomEntityType {
    PLAYER,
    BOT,
    PET
}
