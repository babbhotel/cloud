package com.cometproject.server.game.players.types;

public interface PlayerComponent extends com.cometproject.api.game.players.data.PlayerComponent {

}
