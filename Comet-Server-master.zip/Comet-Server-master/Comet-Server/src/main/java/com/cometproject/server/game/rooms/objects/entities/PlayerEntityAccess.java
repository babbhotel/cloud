package com.cometproject.server.game.rooms.objects.entities;

import com.cometproject.server.game.players.types.Player;


public interface PlayerEntityAccess {
    Player getPlayer();
}
