package com.cometproject.server.game.catalog.types;

public enum VoucherType {
    COINS,
    DUCKETS,
    VIP_POINTS,
    ROOM_BUNDLE
}
