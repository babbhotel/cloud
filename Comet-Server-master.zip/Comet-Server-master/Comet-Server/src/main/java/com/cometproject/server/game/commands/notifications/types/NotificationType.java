package com.cometproject.server.game.commands.notifications.types;

public enum NotificationType {
    GLOBAL,
    LOCAL
}
