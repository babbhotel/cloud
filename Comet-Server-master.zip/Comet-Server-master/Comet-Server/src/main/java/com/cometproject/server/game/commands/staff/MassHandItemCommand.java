package com.cometproject.server.game.commands.staff;

import com.cometproject.server.config.Locale;
import com.cometproject.server.game.commands.ChatCommand;
import com.cometproject.server.game.rooms.objects.entities.types.PlayerEntity;
import com.cometproject.server.logging.LogEntryType;
import com.cometproject.server.logging.LogManager;
import com.cometproject.server.logging.entries.StaffLogEntry;
import com.cometproject.server.network.sessions.Session;


public class MassHandItemCommand extends ChatCommand {
    @Override
    public void execute(Session client, String[] params) {
        if (params.length != 1) {
            sendNotif(Locale.getOrDefault("command.masshanditem.none", "To give everyone in the room an handitem type :masshanditem %number%"), client);
            return;
        }

        try {
            int handItem = Integer.parseInt(params[0]);

            try {
                if (LogManager.ENABLED)
                    LogManager.getInstance().getStore().getLogEntryContainer().putStaff(new StaffLogEntry(client.getPlayer().getId(), -1, "Command: " + Locale.get("command.masshanditem.name"), LogEntryType.NONE));
            } catch (Exception ignored) {

            }

            for (PlayerEntity playerEntity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
                playerEntity.carryItem(handItem, false);
            }

        } catch (Exception e) {
            sendNotif(Locale.get("command.masshanditem.invalidid"), client);
        }
    }

    @Override
    public String getPermission() {
        return "masshanditem_command";
    }

    @Override
    public String getParameter() {
        return Locale.getOrDefault("command.parameter.number", "%number%");
    }

    @Override
    public String getDescription() {
        return Locale.get("command.masshanditem.description");
    }
}