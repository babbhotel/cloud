package com.cometproject.server.game.navigator.types.search;

public class NavigatorSearchRecord {
}
