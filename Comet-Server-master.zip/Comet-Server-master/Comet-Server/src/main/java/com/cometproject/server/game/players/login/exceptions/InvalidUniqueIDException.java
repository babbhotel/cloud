package com.cometproject.server.game.players.login.exceptions;

public class InvalidUniqueIDException extends PlayerLoginException {
}
