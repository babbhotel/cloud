package com.cometproject.server.game.bots;

public enum BotMode {
    RELAXED,
    DEFAULT
}
