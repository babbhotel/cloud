package com.cometproject.server.game.rooms.objects.entities.types.ai.bots;

import com.cometproject.server.game.rooms.objects.entities.RoomEntity;
import com.cometproject.server.game.rooms.objects.entities.types.ai.AbstractBotAI;


public class DefaultAI extends AbstractBotAI {

    public DefaultAI(RoomEntity entity) {
        super(entity);
    }
}
