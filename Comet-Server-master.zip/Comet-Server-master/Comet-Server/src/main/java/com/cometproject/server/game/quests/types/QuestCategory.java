package com.cometproject.server.game.quests.types;

public enum QuestCategory {
//    ROOM_BUILDER(2),
//    SOCIAL(3),
//    IDENTITY(4),

}
