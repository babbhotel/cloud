package com.cometproject.server.game.rooms.objects.entities.types.ai.pets;

public enum PetAction {
    WALK,
    TALK,
    SIT,
    LAY,
    PLAY
}
