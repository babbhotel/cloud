package com.cometproject.server.game.players.login.exceptions;

public class IPBannedException extends PlayerLoginException {
}
