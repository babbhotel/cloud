package com.cometproject.server.game.rooms.objects.items;

public enum RoomItemType {
    FLOOR,
    WALL
}
