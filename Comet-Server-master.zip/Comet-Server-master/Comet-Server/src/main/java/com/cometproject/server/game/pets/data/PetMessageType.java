package com.cometproject.server.game.pets.data;

public enum PetMessageType {
    GENERIC, SCRATCHED, WELCOME_HOME, HUNGRY, TIRED
}
