package com.cometproject.server.game.polls.types.questions;

import com.cometproject.server.game.polls.types.PollQuestion;
import com.cometproject.server.game.polls.types.PollQuestionType;

public class WordedPollQuestion extends PollQuestion {
    public WordedPollQuestion(String question) {
        super(question);
    }

    @Override
    public int getType() {
        return 3;
    }

}
