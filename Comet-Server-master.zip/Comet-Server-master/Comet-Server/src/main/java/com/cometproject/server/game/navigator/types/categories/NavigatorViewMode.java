package com.cometproject.server.game.navigator.types.categories;

public enum NavigatorViewMode {
    REGULAR,
    THUMBNAIL
}
