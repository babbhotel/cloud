package com.cometproject.server.game.players.login.exceptions;

public class PlayerBannedException extends PlayerLoginException {
}
