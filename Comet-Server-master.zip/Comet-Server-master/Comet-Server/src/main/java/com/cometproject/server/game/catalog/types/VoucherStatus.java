package com.cometproject.server.game.catalog.types;

public enum VoucherStatus {
    UNCLAIMED,
    CLAIMED
}
