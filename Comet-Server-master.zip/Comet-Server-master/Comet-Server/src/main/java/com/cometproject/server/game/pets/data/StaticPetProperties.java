package com.cometproject.server.game.pets.data;

public class StaticPetProperties {
    public static final int DEFAULT_LEVEL = 1;
    public static final int DEFAULT_ENERGY = 100;
    public static final int DEFAULT_HAPPINESS = 100;
    public static final int DEFAULT_EXPERIENCE = 0;
}
