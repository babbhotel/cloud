package com.cometproject.server.game.catalog.types;

public enum CatalogPageType {
    DEFAULT, BUNDLE, NORMAL, RECENT_PURCHASES
}
