package com.cometproject.server.game.achievements.types;

public enum AchievementCategory {
    IDENTITY,
    EXPLORE,
    MUSIC,
    SOCIAL,
    GAMES,
    ROOM_BUILDER,
    PETS
}
