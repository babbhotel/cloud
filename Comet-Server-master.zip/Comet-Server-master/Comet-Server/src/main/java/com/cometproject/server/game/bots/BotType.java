package com.cometproject.server.game.bots;

public enum BotType {
    GENERIC,
    WAITER,
    MIMIC,
    SPY
}