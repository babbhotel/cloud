package com.cometproject.server.game.players.login.exceptions;

public abstract class PlayerLoginException extends Exception {
}
