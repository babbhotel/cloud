package com.cometproject.server.game.quests.types;

public enum QuestReward {
    ACHIEVEMENT_POINTS,
    VIP_POINTS,
    ACTIVITY_POINTS,
    CREDITS
}
