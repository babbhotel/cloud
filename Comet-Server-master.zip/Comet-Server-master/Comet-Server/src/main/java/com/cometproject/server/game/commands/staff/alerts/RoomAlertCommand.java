package com.cometproject.server.game.commands.staff.alerts;

import com.cometproject.server.config.Locale;
import com.cometproject.server.game.commands.ChatCommand;
import com.cometproject.server.game.rooms.objects.entities.types.PlayerEntity;
import com.cometproject.server.logging.LogEntryType;
import com.cometproject.server.logging.LogManager;
import com.cometproject.server.logging.entries.StaffLogEntry;
import com.cometproject.server.network.messages.outgoing.notification.AlertMessageComposer;
import com.cometproject.server.network.sessions.Session;


public class RoomAlertCommand extends ChatCommand {
    @Override
    public void execute(Session client, String[] params) {
        if (client.getPlayer() == null || client.getPlayer().getEntity() == null) {
            return;
        }

        try {
            if (LogManager.ENABLED)
                LogManager.getInstance().getStore().getLogEntryContainer().putStaff(new StaffLogEntry(client.getPlayer().getId(), -1, this.merge(params), LogEntryType.ALERT));
        } catch (Exception ignored) {

        }

        for (PlayerEntity entity : client.getPlayer().getEntity().getRoom().getEntities().getPlayerEntities()) {
            entity.getPlayer().getSession().send(new AlertMessageComposer(this.merge(params)));
        }
    }

    @Override
    public String getPermission() {
        return "roomalert_command";
    }

    @Override
    public String getParameter() {
        return Locale.getOrDefault("command.parameter.message", "%message%");
    }

    @Override
    public String getDescription() {
        return Locale.get("command.roomalert.description");
    }
}