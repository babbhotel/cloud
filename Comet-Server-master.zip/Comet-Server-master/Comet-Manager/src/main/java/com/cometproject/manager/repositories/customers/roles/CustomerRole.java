package com.cometproject.manager.repositories.customers.roles;

public enum CustomerRole {
    DEVELOPER,
    CUSTOMER,
    ADMINISTRATOR,
    SUPPORT
}
